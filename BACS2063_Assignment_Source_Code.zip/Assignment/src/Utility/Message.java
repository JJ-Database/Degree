package Utility;
import java.awt.Robot;
import java.awt.AWTException;
import java.awt.event.KeyEvent;


public class Message {
    
    public static void errorChoiceMessage(){
        System.out.println("\n Invalid choice selected");
    }
    public static void exitMessage(){
        System.out.println("\n Exiting Program");
    }
    public static void CLS() throws AWTException, InterruptedException {
        //Robot keyDetect = new Robot();
        //keyDetect.keyPress(KeyEvent);
         try {
            Robot robot = new Robot();
            
            // Depending on your platform, you may need to modify the key presses
            if (System.getProperty("os.name").toLowerCase().contains("win")) {
                // For Windows, you can use the Ctrl+L shortcut
                robot.keyPress(KeyEvent.VK_CONTROL);
                robot.keyPress(KeyEvent.VK_L);
                robot.keyRelease(KeyEvent.VK_L);
                robot.keyRelease(KeyEvent.VK_CONTROL);
                Thread.sleep(20);
            }
        } catch (AWTException e) {
            throw new AWTException("Failed to clear console screen: " + e.getMessage());
        }
}

    
}
