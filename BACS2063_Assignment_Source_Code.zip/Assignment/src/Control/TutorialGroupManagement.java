package Control;


import ADT.*;
import Boundary.*;
import Entity.*;
import Utility.*;
import java.time.LocalDate;
import java.util.function.Predicate;
import java.awt.AWTException;

//author: Song Chan Zhen
public class TutorialGroupManagement {
  
    private HashedDictionary<Integer, Student> studentHash 
            = new HashedDictionary<>();
    private HashedDictionary<Integer, TutorialGroup> groupHash 
            = new HashedDictionary<>();
    private HashedDictionary<String, Programme> prgHash 
            = new HashedDictionary<>();
    private HashedDictionary<Integer, Tutor> tutorHash 
            = new HashedDictionary<>();
    private TutorManagementUI tutorUI = new TutorManagementUI();
    private TutorialGroupManagementUI grpUI = new TutorialGroupManagementUI();
    private ProgrammeManagementUI prgUI = new ProgrammeManagementUI();
    private CourseManagementUI courseUI = new CourseManagementUI();
    public void tutorGrpMain() throws InterruptedException{
        

        groupHash.add(001, new TutorialGroup(001,"RSDG1", 
                "BACS2163","JoSHua"));
        groupHash.add(002, new TutorialGroup(002,"RSDG2", 
                "BACS2244","Sebastian"));
        groupHash.add(003, new TutorialGroup(003,"RDSG1", 
                "BACS2163","JoSHua"));
        groupHash.add(004, new TutorialGroup(004,"RDSG2", 
                "BACS2244","Sebastian"));
        groupHash.add(005, new TutorialGroup(005,"RITG1", 
                "BACS2333","JoSHua"));
        studentHash.add(2203916, new Student(2203916,
                "Ong Zu Liang",'M',"010412070021",
                "01120643114","OZL@gmail.com",
                "RSDG1","Y2S1","FOCS"));
        studentHash.add(2204444, new Student(2204444,
                "Wong Yoke Sin",'M',"020708078891",
                "0112556666","Mike@gmail.com",
                "RSDG1","Y2S1","FOCS"));
        studentHash.add(2201234, new Student(2201234,
                "Song Chan Zhen",'M',"010412070021",
                "01120643114","OZL@gmail.com",
                "RSDG2","Y1S2","FOET"));
        studentHash.add(2204321, new Student(2204321,
                "Wong Yoke Sin",'M',"010412070021",
                "01120643114","OZL@gmail.com",
                "RSDG2","Y1S2","FOET"));
        
         int choice = 0;
        do{
            choice = grpUI.mainMenuChoice();
            switch (choice) {
                case 0:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                      
                    Message.exitMessage();
                    break;
                case 1:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                      
                    addStudent();
                    break;
                case 2:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                      
                    removeStudent();
                    break;
                    
                case 3:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                      
                    changeStudent();
                    break;
                case 4:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                      
                    findStudent();
                    break;
                case 5:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                      
                    listStudent();
                    break;
                case 6:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                      
                    filterStudent();
                    break;
                case 7:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                      
                    generateReport();
                    break;                   
                default:
                    System.out.println("Error");
            }
        }while(choice!=0);
    }
     public void addStudent(){
        
        Student newStudent = grpUI.inputStudentDetails();
        
        if (studentHash.contains(newStudent.getId())){
            grpUI.repeatStudent();
        }
        else{
            studentHash.add(newStudent.getId(), newStudent);   
            System.out.println("Student added successfully");
        }
    }
     public void removeStudent(){
        int removeId = grpUI.inputId();
        
        
        if (studentHash.contains(removeId)){
            Student tempStudent = studentHash.getValue(removeId);
            grpUI.listStudent(tempStudent);
            char confirm = grpUI.confirmRemove();
            
            if (confirm == 'Y'){
                tempStudent.setTutorialGroup(null);
                System.out.println("The student has been removed from the tutorial group successfully");
                Student removeStudent = studentHash.getValue(removeId);
                grpUI.listStudent(removeStudent);
            }else{
                System.out.println("Action cancelled. The student remains in the tutorial group");
            }
        }
        else{
            grpUI.noStudent();           
            
        }
    }
     public void changeStudent(){
         int changeId = grpUI.inputId();
         
         
         
         if (studentHash.contains(changeId)){
            Student tempStudent = studentHash.getValue(changeId);
            grpUI.listStudent(tempStudent);
            grpUI.clearBuffer();
            String tempTGroup = grpUI.inputTGroup();
            tempStudent.setTutorialGroup(tempTGroup);
             System.out.println("The tutorial group of the student "
                     + "has been changed scuccessfully");
        }
        else{
            grpUI.noStudent();           
            
        }
     }
     public void listStudent(){
         String tempTGroup = grpUI.inputTGroup();
         Predicate<Student> tGroupPredicate = student -> 
                 student.getTutorialGroup().equals(tempTGroup);
         System.out.println("List of Student of specific tutorial groups:");
         studentHash.listItemsMatchingCriteria(tGroupPredicate);
    }
     
    public void findStudent(){
        int findId = grpUI.inputId();
        if (studentHash.contains(findId)){
            Student tempStudent = studentHash.getValue(findId);
            System.out.println("Student found: ");
            grpUI.listStudent(tempStudent);
        }else{
            grpUI.noStudent();
        }
    }
    public void filterStudent(){
        System.out.println("Filter tutorial groups based on Programme ");
        String tempCourse = prgUI.inputPrgCode();
        Predicate<TutorialGroup> coursePredicate = tutorialGroup -> 
                tutorialGroup.getProgramme().equals(tempCourse);
        System.out.println("List of tutorials group based on Programme");
        groupHash.listItemsMatchingCriteria(coursePredicate);
        
        
    }
    public void generateReport(){
        System.out.println("=================================");
        System.out.println("Detail Report of Tutorial Group");
        System.out.println("=================================");
        groupHash.listAllItems();
        System.out.println("=================================");
        System.out.println("==================================");
        System.out.println("Detail Report of Students");
        System.out.println("==================================");
          studentHash.listAllItems();
        System.out.println("==================================");
    }
    
    
    public static void main(String[] args) throws InterruptedException {
        TutorialGroupManagement tutorialGroupManagement 
                = new TutorialGroupManagement();

        tutorialGroupManagement.tutorGrpMain();
        
    }
    

}
