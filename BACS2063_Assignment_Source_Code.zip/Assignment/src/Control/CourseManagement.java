package Control;

import ADT.*;
import Boundary.TutorManagementUI;
import Entity.*;
import java.util.function.Predicate;
import java.text.SimpleDateFormat;
import Boundary.*;
import java.awt.Robot;
import java.awt.AWTException;
import java.io.IOException;
import java.awt.event.KeyEvent;
import Utility.Message;

//author: Wong Yoke Sin
public class CourseManagement {
    private static SimpleDateFormat dateDisplay = new SimpleDateFormat("dd-MM-yyyy");
    private ProgrammeManagementUI prgUI = new ProgrammeManagementUI();
    //private TutorManagementUI tutorUI = new TutorManagementUI();
    //private TutorialGroupManagementUI grpUI = new TutorialGroupManagementUI();
    private CourseManagementUI courseUI = new CourseManagementUI();
    //private UniversityManagementUI universityUI = new UniversityManagementUI();
    
    private HashedDictionary<String,Course> courseHash = new HashedDictionary<>();
    private HashedDictionary<String,Programme> prgHash = new HashedDictionary<>();
    
    public void courseMain() throws InterruptedException{
        prgHash.add("BACS2163", new Programme("BACS2163",
                "Software Engineering","Degree",500.00));
        prgHash.add("BACS2244", new Programme("BACS2244",
                "Object Oriented Programming","Degree",
                500.00));
        prgHash.add("BACS2333", new Programme("BACS2333",
                "Computer Science","Diploma",500.00));
        prgHash.add("BACS2255", new Programme("BACS2255",
                "System Analysis & Design","Degree",
                500.00));
        courseHash.add("RSD", new Course("RSD",
                "Software System Developement","Degree"));
        courseHash.add("RIT", new Course("RSW",
                "Software Engineering","Degree"));
        courseHash.add("RDS", new Course("RDS",
                "Data Science","Diploma"));
        courseHash.add("RIT", new Course("RIT",
                "Internet Technology","Diploma"));
        courseHash.add("RIT", new Course("RIS",
                "Information Security","Degree")); 
        int choice = 0;
        do{
            choice = courseUI.mainMenuChoice();
            switch (choice) {
                case 0:
                    
                    Message.exitMessage();
                    break;
                case 1:
                     try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    addCourse();
                    break;
                case 2:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    removeCourse();
                    break;
                    
                case 3:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    findCourse();
                    break;
                case 4:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    updateCourse();
                    break;
                case 5:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    listCourse();
                    break;
                case 6:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    addProgram();
                    break;
                case 7:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    removeProgram();
                    break;
                case 8:
                     try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    generateReport();
                    break;
                default:
                    System.out.println("Error");
            }
        }while(choice!=0);
        
    }
    public void addCourse(){
        
        Course newCourse = courseUI.inputCourseDetails();
        
        if (courseHash.contains(newCourse.getCourseCode())){
            courseUI.repeatCourse();
        }
        else{
            courseHash.add(newCourse.getCourseCode(),newCourse );
            System.out.println("Course has been added succesfully!!");
        }
        
    }
    public void removeCourse(){
        String removeId = courseUI.inputCourseCode();
        
        if (courseHash.contains(removeId)){
            courseHash.remove(removeId);
            System.out.println("The course has been removed successfully!!");
        }
        else{
            courseUI.noCourse();           
            
        }
    }
    public void findCourse(){
        String findId = courseUI.inputCourseCode();
        if (courseHash.contains(findId)){
            Course tempCourse = courseHash.getValue(findId);
            System.out.println("Course found:");
            courseUI.listCourse(tempCourse);
        }else{
            courseUI.noCourse();
        }
    }
    public void listCourse(){
        System.out.println("The list of all course");
        courseHash.listAllItems();
    }
    private void updateCourse(){
        String updateId = courseUI.inputCourseCode();
        Course tempCourseDetail = courseHash.getValue(updateId);
        if(courseHash.contains(updateId)){
            Course tempCourse = courseHash.getValue(updateId);
            courseUI.listCourse(tempCourse);
            
            String tempCourseTitle = courseUI.inputCourseTitle();
            String tempCourseType = courseUI.inputCourseType();
            
            tempCourseDetail.setCourseTitle(tempCourseTitle);
            tempCourseDetail.setCourseType(tempCourseType);
        }
    }
   
    public void addProgram(){
        String tempPrgId = prgUI.inputPrgCode();
        Programme tempPrg = prgHash.getValue(tempPrgId);
        if(prgHash.contains(tempPrgId)){
            prgHash.getValue(tempPrgId);
            String tempCourse = courseUI.inputCourseCode();
            
            
            
            tempPrg.setCourse(tempCourse);
            prgUI.listProgramme( tempPrg);
            System.out.println("Program added successfully");
        }else{
            System.out.println("Programme is not found");
        }
    }
        public void removeProgram(){
            
        String tempPrgId = prgUI.inputPrgCode();
        Programme tempPrg = prgHash.getValue(tempPrgId);
        if(prgHash.contains(tempPrgId)){
            prgHash.getValue(tempPrgId);
            
            
            char confirm = courseUI.confirmRemove();
            
            if (confirm == 'Y'){
                tempPrg.setCourse(null);
                prgUI.listProgramme( tempPrg);
                System.out.println("The programme has been"
                        + " successfully removed");
                
            }else{
                System.out.println("Action cancelled. The programme "
                        + "remain in the course");
            }
        }
            
            
            
        
        }
        
        
            
            

        
    
    public void generateReport() {
        System.out.println("===============================");
        System.out.println("Detail Reports for Programme");
        System.out.println("===============================");
        prgHash.listAllItems();
        System.out.println("===============================");
        System.out.println("===============================");
        System.out.println("Detail Reports for Course");
        System.out.println("===============================");
        courseHash.listAllItems();
        System.out.println("===============================");
    }
     public static void main(String[] args) throws InterruptedException {
        CourseManagement courseManagement = new CourseManagement();

        courseManagement.courseMain();
        
    }
    

}

