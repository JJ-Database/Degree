package Control;

import ADT.*;
import Boundary.*;
import Entity.*;
import Utility.*;
import java.text.SimpleDateFormat;
import java.util.function.Predicate;
import java.awt.AWTException;
import Utility.Message;

//author: Ma Yu Chuan

public class ProgrammeManagement {
    
    private static SimpleDateFormat dateDisplay
            = new SimpleDateFormat("dd-MM-yyyy");
    private ProgrammeManagementUI prgUI = new ProgrammeManagementUI();
    private TutorManagementUI tutorUI = new TutorManagementUI();
    private TutorialGroupManagementUI grpUI = new TutorialGroupManagementUI();
    //private CourseManagementUI courseUI = new CourseManagementUI();
   
    private HashedDictionary<String, Programme> programmeHash 
            = new HashedDictionary<>();
    private HashedDictionary<Integer, TutorialGroup> groupHash 
            = new HashedDictionary<>();
    
    
    public void programmeMain() throws InterruptedException {
        groupHash.add(001, new TutorialGroup(001,"RSDG1",
                "BACS2163","JoSHua"));
        groupHash.add(002, new TutorialGroup(002,"RSDG2", 
                "BACS2244","Sebastian"));
        groupHash.add(003, new TutorialGroup(003,"RDSG1", 
                "BACS2163","JoSHua"));
        groupHash.add(004, new TutorialGroup(004,"RDSG2", 
                "BACS2244","Sebastian"));
        groupHash.add(005, new TutorialGroup(005,"RITG1", 
                "BACS2333","JoSHua"));
        programmeHash.add("BACS2163", new Programme("BACS2163",
                "Software Engineering","Degree",500.00));
        programmeHash.add("BACS2244", new Programme("BACS2244",
                "Object Oriented Programming","Degree",
                500.00));
        programmeHash.add("BACS2333", new Programme("BACS2333",
                "Computer Science","Diploma",500.00));
        programmeHash.add("BACS2255", new Programme("BACS2255",
                "System Analysis & Design","Degree",
                500.00));
        
        
       int choice = 0;
        do{
            choice = prgUI.mainMenuChoice();
            switch (choice) {
                case 0:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                    
                    Message.exitMessage();
                    break;
                case 1:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                    
                    addProgramme();
                    break;
                case 2:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                    
                    removeProgramme();
                    break;
                    
                case 3:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                    
                    findProgramme();
                    break;
                case 4:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                    
                    updateProgramme();
                    break;
                case 5:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                    
                    listProgramme();
                    break;
                case 6:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                    
                    addTutorGrp();
                    break;
                    
                case 7:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                    
                    removeTutorGrp();
                    break;
                case 8:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                    
                    listTutorGrp();
                    break;
                case 9:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }                    
                    generateReport();
                    break;
                    
                
               default:
                    System.out.println("Error");
            }
        }while(choice!=0);
        
        
    }
    public void addProgramme(){
        
        Programme newProgramme = prgUI.inputProgrammeDetails();
        
        if (programmeHash.contains(newProgramme.getProgrammeCode())){
            prgUI.repeatProgramme();
        }
        else{
            programmeHash.add(newProgramme.getProgrammeCode(), 
                    newProgramme);   
            System.out.println("Programme added successfully");
        }
    }
    public void removeProgramme(){
        String removeId = prgUI.inputPrgCode();
        
        if (programmeHash.contains(removeId)){
            programmeHash.remove(removeId);
            System.out.println("Programme has been removed successfully");
        }
        else{
            prgUI.noProgramme();
        }
        
    }
    public void findProgramme(){
        String findId = prgUI.inputPrgCode();
        if (programmeHash.contains(findId)){
            Programme tempProgramme = programmeHash.getValue(findId);
            System.out.println("Programme found");
            prgUI.listProgramme(tempProgramme);
        }else{
            prgUI.noProgramme();
        }
    }
    
    public void listProgramme(){
        System.out.println("List of Programmes:");
        programmeHash.listAllItems();
       
    }
        public void updateProgramme(){
       
        String updateId = prgUI.inputPrgCode();
        
        if (programmeHash.contains(updateId)){
            Programme tempProgramme = programmeHash.getValue(updateId);
            prgUI.listProgramme(tempProgramme);
            
            String tempPrgName = prgUI.inputPrgName();
            String tempPrgType = prgUI.inputPrgType();
            double tempPrgFee = prgUI.inputPrgFee();
            
            tempProgramme.setProgrammeName(tempPrgName);
            tempProgramme.setProgrammeType(tempPrgType);
            tempProgramme.setProgrammeFee(tempPrgFee);
            System.out.println("The details of the programme "
                    + "has been succesful");
      
            
        }else{
            prgUI.noProgramme();
        }
          
    }
        public void addTutorGrp(){
            TutorialGroup newTGroup = prgUI.inputTutorialDetails();
        
        if (groupHash.contains(newTGroup.getGroupId())){
            prgUI.repeatTGroup();
        }
        else{
            groupHash.add(newTGroup.getGroupId(), newTGroup);
            System.out.println("Tutorial group added successfully");
            
        }
        }
        public void removeTutorGrp(){
            int removeId = prgUI.inputGrpId();
        
        if (groupHash.contains(removeId)){
            groupHash.remove(removeId);
            System.out.println("Tutorial group removed successfully");
        }
        else{
            prgUI.noProgramme();           
            
        }
        
            
        }
       
        public void listTutorGrp(){
         String listId = prgUI.inputPrgCode();
         Predicate<TutorialGroup> tGroupPredicate = tutorialGroup 
                 -> tutorialGroup.getProgramme().equals(listId);
         groupHash.listItemsMatchingCriteria(tGroupPredicate);
        }
        
    
        public void generateReport(){
            System.out.println("====================================");
            System.out.println("Detail Report for Programme");
            System.out.println("====================================");
            programmeHash.listAllItems();
            System.out.println("====================================");
            System.out.println("======================================="
                    + "===========");
            System.out.println("Details Reports of the Tutorial Groups");
            System.out.println("========================================"
                    + "===========");
            groupHash.listAllItems();
            System.out.println("======================================="
                    + "============");
        }
        public static void main(String[] args) throws InterruptedException {
            ProgrammeManagement programmeManagement = new ProgrammeManagement();
            programmeManagement.programmeMain();
    }
        
        
        
}
