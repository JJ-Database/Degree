package Control;

import ADT.*;
import Boundary.TutorManagementUI;
import Entity.*;
import java.util.function.Predicate;
import java.text.SimpleDateFormat;
import Boundary.*;
import java.awt.AWTException;
import Utility.Message;
import java.time.LocalDate;

//author: Ong Zu Liang
public class TutorManagement {
    private static SimpleDateFormat dateDisplay 
            = new SimpleDateFormat("dd/MM/yyyy");
    private HashedDictionary<Integer, Tutor> tutorHash = new HashedDictionary<>();
    

    
    private TutorManagementUI tutorUI = new TutorManagementUI();
    
    public void tutorMain() throws InterruptedException{
        tutorHash.add(1000,new Tutor(1000, "Joshua Chew", 
                'M',"010413070023","01120643114",
                "Joshua@Gmail.com","FOCS",4000.00,
                LocalDate.of(2012, 1, 23)));
        tutorHash.add(1001,new Tutor(1001, "Ong Zu Liang", 
                'M',"010413070023","01120643114",
                "OngZL@Gmail.com","FOCS",4000.00,
                LocalDate.of(2012, 1, 23)));
        tutorHash.add(1002,new Tutor(1002, "Tang Tzu Li", 
                'F',"030120070223","01289793742",
                "TangTL@Yahoo.com","FAFB",3500.00,
                LocalDate.of(2014, 4, 23)));
        tutorHash.add(1003,new Tutor(1003, "Ma Yu Chuan", 
                'M',"030102070921","0178946736",
                "AndrewMA@Gmail.com","FOET",6000.00,
                LocalDate.of(2011, 5, 13)));
        tutorHash.add(1004,new Tutor(1004, "Leong Yuen Theng", 
                'F',"030813070342","01273473298",
                "LeongYT@Outlook.com","FOCS",4000.00,
                LocalDate.of(2015, 7, 11)));
        tutorHash.add(1005,new Tutor(1005, "Song Chan Zhen", 
                'M',"030724070452","01178352090",
                "SongCZ@Gmail.com","FCCI",4000.00,
                LocalDate.of(2012, 2, 27)));
      


        int choice = 0;
        do{
            choice = tutorUI.mainMenuChoice();
            switch (choice) {
                case 0:
                    
                    Message.exitMessage();
                    break;
                case 1:
                     try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    addTutor();
                    break;
                case 2:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    removeTutor();
                    break;
                    
                case 3:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    findTutor();
                    break;
                case 4:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    updateTutor();
                    break;
                case 5:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    listTutor();
                    break;
                case 6:
                    try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                    filterTutor();
                    break;
                case 7:
                      try {
                    // Clear the console screen
                    Message.CLS();
                     }catch (AWTException e) {
                         System.err.println("Error: " + e.getMessage());
                     }
                     generateReport();
                     break;
                default:
                    System.out.println("Error");
            }
        }while(choice!=0);
        
    }
    public void addTutor(){
        
        Tutor newTutor = tutorUI.inputTutorDetails();
        
        if (tutorHash.contains(newTutor.hashCode())){
            tutorUI.repeatTutor();
        }
        else{
            tutorHash.add(newTutor.hashCode(), newTutor);
            System.out.println("Tutor added succesufully;");
        }
        
    }
    
    public void listTutor(){
        tutorHash.listAllItems();
    }
    
    public void removeTutor(){
        int removeId = tutorUI.inputTutorId();
        
        if (tutorHash.contains(removeId)){
            tutorHash.remove(removeId);
            System.out.println("Tutor removed successfully");
        }
        else{
            tutorUI.noTutor();           
            
        }
     
    }
    public void updateTutor(){
       
        int updateId = tutorUI.inputTutorId();
       

        if(tutorHash.contains(updateId)){
            Tutor tempTutor = tutorHash.getValue(updateId);
            tutorUI.listTutor(tempTutor);
            tutorUI.clearBuffer();
            String tempName = tutorUI.inputTutorName();
            char tempGender =tutorUI.inputTutorGender();
            String tempIcNo =tutorUI.inputTutorIcNo();
            String tempContactNo=tutorUI.inputTutorContactNo();
            String tempEmail=tutorUI.inputTutorEmail();
            String tempFaculty=tutorUI.inputTutorFaculty();
            double tempSalary=tutorUI.inputTutorSalary();
            LocalDate tempDate=tutorUI.inputTutorDate();
            
            tempTutor.setName(tempName);
            tempTutor.setGender(tempGender);
            tempTutor.setIcNo(tempIcNo);
            tempTutor.setContactNo(tempContactNo);
            tempTutor.setEmail(tempEmail);
            tempTutor.setFaculty(tempFaculty);
            tempTutor.setSalary(tempSalary);
            tempTutor.setDate(tempDate);
            System.out.println("Tutor infor is update succesfully");
        }
            
            
        else{
            tutorUI.noTutor();
        }
    }
          
    
    public void findTutor(){
        int findId = tutorUI.inputTutorId();
        if (tutorHash.contains(findId)){
            Tutor tempTutor = tutorHash.getValue(findId);
            System.out.println("Tutor found: ");
            tutorUI.listTutor(tempTutor);
        }else{
            tutorUI.noTutor();
        }
    }
    public void filterTutor(){
        
        
        int filterOpt = tutorUI.filterOpt();
        
        switch(filterOpt){
            case 1:
                char genderFilter = tutorUI.genderFilter();
                Predicate<Tutor> genderPredicate = tutor -> tutor.getGender() 
                        == genderFilter;
                System.out.println("List of Tutor with " + genderFilter + " gender");
                tutorHash.listItemsMatchingCriteria(genderPredicate);
                break;
            case 2:
                String facultyFilter = tutorUI.inputTutorFaculty();
                
                tutorUI.clearBuffer();
                Predicate<Tutor>facultyPredicate = tutor -> tutor.getFaculty().
                        equals(facultyFilter);
                System.out.println("List of Tutor of Faculty" + facultyFilter);
                tutorHash.listItemsMatchingCriteria(facultyPredicate);
                break;
        
        }
       
        
        
    }
    
    public void generateReport(){
       
        System.out.println("==============================");
        System.out.println("  Detail Reports of Tutors");
        System.out.println("==============================");
        tutorHash.listAllItems();
        System.out.println("==============================");
    }
    public static void main(String[] args) throws InterruptedException {
        TutorManagement tutorManagement = new TutorManagement();

        tutorManagement.tutorMain();
        
    }
}
