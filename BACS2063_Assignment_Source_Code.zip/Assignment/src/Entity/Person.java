package Entity;
public class Person {
    private int id;
    private String name;
    private char gender;
    private String icNo;
    private String contactNo;
    private String email;
    private String faculty;
    
    public Person(){
        
    }
    public Person(int id,String name, char gender, String icNo, String contactNo,String email,String faculty){
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.icNo = icNo;
        this.contactNo = contactNo;
        this.email = email;
        this.faculty = faculty;
    }
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id = id;   
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public char getGender() {
        return gender;
    }
    public void setGender(char gender) {
        this.gender = gender;
    }
    public String getIcNo(){
        return icNo;
    }
    public void setIcNo(String icNo){
        this.icNo = icNo;
    }
    public String getContactNo(){
        return contactNo;
    }
    public void setContactNo(String contactNo){
        this.contactNo = contactNo;
    }
    public String getEmail(){
        return email;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String getFaculty(){
        return faculty;
    }
    public void setFaculty(String faculty){
        this.faculty = faculty;
    }
    @Override
    public String toString(){
        return String.format("\nId: %d\nName: %s\nGender: %c\nIC No: %s\nContact no: %s\nEmail: %s\nFaculty: %s",id,name,gender,icNo,contactNo,email,faculty);
    }
    
}
