package Entity;
public class Student extends Person {
    
    private String semester;
    private String tutorialGroup;
    

    
    public Student(int id, String name,char gender,String icNo,String contactNo,String email,String tutorialGroup,String semester,String faculty){
        super(id,name,gender,icNo,contactNo,email,faculty);
        this.semester = semester;
        this.tutorialGroup = tutorialGroup;

    }
    public String getSemester(){
        return semester;
    }
    public void setSemester(String semester){
        this.semester = semester;
    }
    public String getTutorialGroup(){
        return tutorialGroup;
    }
    public void setTutorialGroup(String tutorialGroup){
        this.tutorialGroup = tutorialGroup;
    }
    
    @Override
    public String toString() {
        return super.toString() + String.format("\nSemester: %s \nTutorialGroup: %s",semester, tutorialGroup);
    
    }
    
    
}

