package Entity;
public class Course {
    private String courseCode;
    private String courseTitle;
    private String courseType;
    

    public Course(String courseCode, String courseTitle, String courseType) {
        this.courseCode = courseCode;
        this.courseTitle = courseTitle;
        this.courseType = courseType;
    }
   

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public String getCourseType() {
        return courseType;
    }

    public void setCourseType(String courseType) {
        this.courseType = courseType;
    }
    

    @Override
     public String toString() {
        return String.format("\nCourse Code: %s\nCourse Title: %s\nCourse Type: %s",courseCode, courseTitle, courseType);
    }
}
