package Entity;

public class Programme {
    private String prgCode;
    private String prgName;
    private double prgFee;
    private String prgType;
    private String course;


    public Programme(String prgCode, String prgName,String prgType, double prgFee) {
        this.prgCode = prgCode;
        this.prgName = prgName;
        this.prgType = prgType;
        this.prgFee = prgFee;
    }
    public Programme(String prgCode, String prgName,String prgType, double prgFee,String course) {
        this.prgCode = prgCode;
        this.prgName = prgName;
        this.prgType = prgType;
        this.prgFee = prgFee;
        this.course = course;
    }


    public String getProgrammeCode() {
        return prgCode;
    }

    public void setProgrammeCode(String prgCode) {
        this.prgCode = prgCode;
    }

    public String getProgrammeName() {
        return prgName;
    }

    public void setProgrammeName(String prgName) {
        this.prgName = prgName;
    }
    public String getProgrammeType() {
        return prgType;
    }

    public void setProgrammeType(String prgType) {
        this.prgType = prgType;
    }

    
    public double getProgrammeFee() {
        return prgFee;
    }

    public void setProgrammeFee(double prgFee) {
        this.prgFee = prgFee;
    }
    public String getCourse(){
        return course;
    }
    public void setCourse(String course){
        this.course = course;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Programme programme = (Programme) o;
        return prgName.equalsIgnoreCase(programme.prgName);
    }

    @Override
    public String toString() {
        return String.format("\nProgramme Code: %s\nProgramme Name:  %s\nProgramme Type: %s\nProgramme Fee: %.2f\nProgramme Course: %s",prgCode, prgName, prgType, prgFee,course);
    }

    

}