package Entity;

public class TutorialGroup {
    private int groupId;
    private String groupName;
    private String programme;
    private String tutor;

    // Constructor
    public TutorialGroup(int groupId, String groupName, String programme, String tutor) {
        this.groupId = groupId;
        this.groupName = groupName;
        this.programme = programme;
        this.tutor = tutor;
    }

    // Getter and Setter methods
    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getProgramme() {
        return programme;
    }

    public void setProgramme(String programme) {
        this.programme = programme;
    }

    public String getTutor() {
        return tutor;
    }

    public void setTutor(String tutor) {
        this.tutor = tutor;
    }

    @Override
    public String toString() {
        return String.format(" \nGroup ID: %s\nGroup Name: %s\nProgramme Name: %s\nTutor Name: %s ",
                groupId, groupName,programme, tutor);
    }


}
