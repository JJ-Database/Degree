package Entity;

import java.time.LocalDate;
public class Tutor extends Person {
    
    private double salary;
    private LocalDate employDate;
    private TutorialGroup tutorialGroup;
    
    
    
    public Tutor(){}
    
    public Tutor(int id, String name,char gender,String icNo,String contactNo,String email,String faculty, double salary, LocalDate employDate){
        super(id,name,gender,icNo,contactNo,email,faculty);
        this.salary = salary;
        this.employDate = employDate;
    }
    public double getSalary(){
        return salary;
    }
    
    public void setSalary(double salary){
        this.salary = salary; 
    }
    
    public LocalDate getDate(){
        return employDate;
    }
    public void setDate(LocalDate employDate){
        this.employDate = employDate;
    }
    public String toString() {
    return super.toString() + String.format("\nSalary: %s\nEmployement Date: %s",salary,employDate);
    }
    
    
}
