package Boundary;
import Entity.*;
import java.util.Scanner;


public class TutorialGroupManagementUI {
    
    Scanner scanner = new Scanner(System.in);
     
    public int mainMenuChoice() {
    System.out.println("\nTutorial Group Management Menu");
    System.out.println("=================================");
    System.out.println("1. Add Student to Tutorial Group");
    System.out.println("2. Remove Student from Tutorial Group");
    System.out.println("3. Change Student Tutorial Group");
    System.out.println("4. Find Student");
    System.out.println("5. List Student");
    System.out.println("6. Filter Student");
    System.out.println("7. Generate Report");
    System.out.println("0. Back To Main Menu");
    System.out.print("Enter choice: ");
    int choice = scanner.nextInt();
    scanner.nextLine();
    System.out.println();
    return choice;
    
    }   
    public void clearBuffer(){
        scanner.nextLine();
    }
    public char confirmRemove(){
        char Option = 0;
        System.out.println("Are you sure you want to remove the student from the tutorial group? (Y/N)");
        Option = scanner.next().charAt(0);
        return Option;
    }
    public void listStudent(Student student){
         System.out.println("\nList of students:\n" + student);
    }
    public void repeatStudent(){
        System.out.println("The Student is alread assigned to a tutorial group. Please add student with different Id. ");
    }
    public void noStudent(){
        System.out.println("The Student does not exist or had already been deleted ");
    }
    public void emptyStudent(){
        System.out.println("There are currently no student in the tutorial group");
    }
   
    
    
    
    /*public void printStudentDetails(Student student) {
    System.out.println("Student Details");
    System.out.println("Student Name: " + student.getName());
    System.out.println("Student Number: " + student.getNumber());
    System.out.println("Email address: " + student.getEmail());
    System.out.println("Course:" + student.getCourse());
  }*/
    
    public int inputId(){
        System.out.println("Please enter student Id: ");
        int Id = scanner.nextInt();
        return Id;
    }
    public String inputName(){
        System.out.println("Please enter student name: ");
        String name = scanner.nextLine();
        return name;
    }
    public char inputGender(){
        System.out.println("Please enter student gender: ");
        char gender = scanner.next().charAt(0);
        scanner.nextLine();
        return gender;
    }
    
    
    public String inputIC(){
        System.out.println("Please enter student IC no. : ");
        String icNo = scanner.nextLine();
        return icNo;
    }
    
    public String inputContact(){
        System.out.println("Please enter student contact no.: ");
        String contactNo = scanner.nextLine();
        return contactNo;
    }
    public String inputEmail(){
        System.out.println("Please enter student email: ");
        String email = scanner.nextLine();
        return email;
    }
 
    public String inputTGroup(){
        System.out.println("Please enter Tutorial Group Id: ");
        String groupId = scanner.nextLine();
        return groupId;
    }
    public String inputSemester(){
        System.out.println("Please enter student semester: ");
        String semester = scanner.nextLine();
        return semester;
    }
    public String inputFaculty(){
        System.out.println("Please enter student faculty: ");
        String faculty = scanner.nextLine();
        return faculty;
    }

    
    
    public Student inputStudentDetails() {
        int studId = inputId();
        scanner.nextLine();
        String studName = inputName();
        char studGender = inputGender();
        String studIC = inputIC();
        String studContact = inputContact();
        String studEmail = inputEmail();
        String studTGroup = inputTGroup();
        String studSemester = inputSemester();
        String studFaculty = inputFaculty();
        
        return new Student(studId,studName,studGender,studIC,studContact,studEmail,studTGroup,studSemester,studFaculty);
  }
    
    
}
