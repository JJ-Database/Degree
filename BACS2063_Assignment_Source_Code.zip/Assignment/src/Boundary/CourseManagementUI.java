package Boundary;
import Entity.*;

import java.util.Scanner;

public class CourseManagementUI {
    
    Scanner scanner = new Scanner(System.in);
     
    public int mainMenuChoice() {
    System.out.println("\nCourse ManagementMenu");
    System.out.println("1. Add new course");
    System.out.println("2. Remove course");
    System.out.println("3. Find course");
    System.out.println("4. Update course");
    System.out.println("5. List all course");
    System.out.println("6. Add programme to course");
    System.out.println("7. Remove programme from course");
    System.out.println("8. Generate Reports");
    System.out.println("0. Back To Main Menu");
    System.out.print("Enter choice: ");
    int choice = scanner.nextInt();
    scanner.nextLine();
    System.out.println();
    return choice;
    
    }   
    public void clearBuffer(){
        scanner.nextLine();
    }
    public char confirmRemove(){
        char Option = 0;
        System.out.println("System.out.println(\"Are you sure you want to remove the programme from the course?\");");
        Option = scanner.next().charAt(0);
        return Option;
    }
    
    public void listProgramme(Programme programme){
         System.out.println(programme);
    }
    public void listCourse(Course course){
        System.out.println(course);
    }
    public void repeatCourse(){
        System.out.println("The course is already registered. Please add another course with a different Id. ");
    }
    public void noCourse(){
        System.out.println("The course does not exist or had already been deleted ");
    }
    
    public void emptyCourse(){
        System.out.println("There are currently no programme in the database");
    }
    
    public String inputCourseCode(){
        System.out.println("Please enter course code (Exp: RSD) : ");
        String courseCode = scanner.nextLine();
        return courseCode;
    }
    public String inputCourseTitle(){
        System.out.println("Please enter course title (Exp: Mass Communication): ");
        String courseTitle = scanner.nextLine();
        return courseTitle;
    }
    public String inputCourseType(){
        System.out.println("Please enter course type(Degree/Diploma): ");
        String courseType = scanner.nextLine();
        return courseType;
    }
    
   
    
    public Course inputCourseDetails() {
        String courseCode = inputCourseCode();
        String courseTitle = inputCourseTitle();
        String courseType = inputCourseType();
        return new Course(courseCode,courseTitle,courseType);
  }
    
   
    
    
    
}
