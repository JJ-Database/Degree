package Boundary;
import Entity.Tutor;
import java.util.Scanner;
import java.time.LocalDate;

public class TutorManagementUI {
    
    Scanner scanner = new Scanner(System.in);
    
    public int mainMenuChoice(){
        System.out.println("\nTutor Management Menu");
        System.out.println("=================================");
        System.out.println("1. Add tutor");
        System.out.println("2. Remove tutor");
        System.out.println("3. Find Tutor");
        System.out.println("4. Update Tutor");
        System.out.println("5. List Tutors");
        System.out.println("6. Filter Tutors");
        System.out.println("7. Generate Reports");
        System.out.println("0. Back To Main Menu");
        System.out.print("Enter choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();
        System.out.println();
        return choice;
    }
    public void clearBuffer(){
        scanner.nextLine();
    }
    public void listTutor(Tutor tutor){
      System.out.println(tutor);
    }
    public void repeatTutor(){
        System.out.println("The Tutor Id is already used. Please use another Tutor Id. ");
    }
    public void noTutor(){
        System.out.println("The Tutor does not exist or had already been deleted ");
    }
    public void emptyTutor(){
        System.out.println("There are currently no Tutor in the system");
    }
    
    public int filterOpt(){
        System.out.println("Please select your filter method");
        System.out.println("1. Gender");
        System.out.println("2. Faculty");
        int filterOpt = scanner.nextInt();
        return filterOpt;
    }
    public char genderFilter(){
        System.out.println("Please select your gender(M/F):");
        char gender = scanner.next().charAt(0);
        return gender;
    }
    public int inputTutorId(){
        System.out.print("Enter Tutor Id: ");
        int id = scanner.nextInt();

        return id;
    }
    public String inputTutorName(){
        System.out.print("Enter Tutor Name: ");
        String name = scanner.nextLine();
        return name;
    }
    public char inputTutorGender(){
        System.out.print("Enter Gender: ");
        char gender = scanner.next().charAt(0);
        scanner.nextLine();
        return gender;
    }
    public String inputTutorIcNo(){
        System.out.print("Enter TutorIcNo: ");
        String icNo = scanner.nextLine();
        return icNo;
    }
    public String inputTutorContactNo(){
        System.out.print("Enter Contact No: ");
        String contactNo = scanner.nextLine();
        return contactNo;
    }
    public String inputTutorEmail(){
        System.out.print("Enter Tutor Email: ");
        String faculty = scanner.nextLine();
        return faculty;
    }
    public String inputTutorFaculty(){
        System.out.print("Enter Faculty: ");
        String faculty = scanner.nextLine();
        return faculty;
    }
    public String inputCriteria(){
        System.out.print("Enter Criteria");
        String criteria = scanner.nextLine();
        System.out.println();
        return criteria;
    }
    public double inputTutorSalary(){
        System.out.println("Enter tutor salary: ");
        double salary = scanner.nextDouble();
        return salary;
    }
    public LocalDate inputTutorDate(){
        System.out.print("Enter Tutor employement date (year): ");
        int year = scanner.nextInt();
        System.out.print("Enter Tutor employement date (month): ");
        int month = scanner.nextInt();
        System.out.print("Enter Tutor employement date (day): ");
        int day = scanner.nextInt();
        LocalDate date = LocalDate.of(year, month, day);
        return date;
    }
    public Tutor inputTutorDetails(){
        int tutorId = inputTutorId();
        scanner.nextLine();
        String tutorName = inputTutorName();
        char tutorGender = inputTutorGender();
        String tutorIcNo = inputTutorIcNo();
        String tutorContactNo = inputTutorContactNo();
        String tutorEmail = inputTutorEmail();
        String tutorFaculty = inputTutorFaculty();
        double tutorSalary = inputTutorSalary();
        LocalDate tutorEmpDate = inputTutorDate(); 
        return new Tutor(tutorId,tutorName,tutorGender,tutorIcNo,tutorContactNo,tutorEmail,tutorFaculty,tutorSalary,tutorEmpDate);
    }
    
}
