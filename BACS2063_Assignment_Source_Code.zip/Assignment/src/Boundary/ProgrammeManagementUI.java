package Boundary;
import Entity.*;

import java.util.Scanner;

public class ProgrammeManagementUI {
    
    Scanner scanner = new Scanner(System.in);
     
    public int mainMenuChoice() {
    System.out.println("\nMAIN MENU");
    System.out.println("1. Add new programme");
    System.out.println("2. Remove programme");
    System.out.println("3. Find programme");
    System.out.println("4. Update programme");
    System.out.println("5. List all programme");
    System.out.println("6. Add tutorial group to programme");
    System.out.println("7. Remove tutorial group from programme");
    System.out.println("8. List all tutorial group for programme");
    System.out.println("9. Generate Reports");
    System.out.println("0. Back To Main Menu");
    System.out.print("Enter choice: ");
    int choice = scanner.nextInt();
    scanner.nextLine();
    System.out.println();
    return choice;
    
    }   
    public void clearBuffer(){
        scanner.nextLine();
    }
    
    public void listProgramme(Programme programme){
         System.out.println(programme);
    }
    /*public void listProgramme(Programme programme){
        System.out.println(programme);
    }*/
    public void repeatProgramme(){
        System.out.println("The programme is already registered. Please add programme with different Id. ");
    }
    public void repeatTGroup(){
        System.out.println("The tutorial group for the program is already added.");
    }
    public void noProgramme(){
        System.out.println("The programme does not exist or had already been deleted ");
    }
    
    public void emptyProgramme(){
        System.out.println("There are currently no programme in the database");
    }
    public void emptyTGroup(){
        System.out.println("There are currently no tutorial group for this program");
    }
    
    public String inputPrgCode(){
        System.out.println("Please enter programme code (Exp: BACS 2163) : ");
        String prgCode = scanner.nextLine();
        return prgCode;
    }
    public String inputPrgName(){
        System.out.println("Please enter programme name (Exp: Human Computer Interaction): ");
        String prgName = scanner.nextLine();
        return prgName;
    }
    public String inputPrgType(){
        System.out.println("Please enter programme type (Diploma/Degree): ");
        String prgType = scanner.nextLine();
        return prgType;
    }
    public double inputPrgFee(){
        System.out.println("Please enter program fee(XX.XXXX): ");
        double prgFee = scanner.nextDouble();
        return prgFee;
    }
    public int inputGrpId(){
        System.out.println("Please enter tutorial group id (Exp: 001) : ");
        int grpId = scanner.nextInt();
        return grpId;
    }
    
    public String inputGrpName(){
        System.out.println("Please enter tutorial group name (RSDG1) : ");
        String grpName = scanner.nextLine();
        return grpName;
    }
    
    public String inpurGrpProgram(){
        System.out.println("Please enter the tutorial group programme (BACS 2023)");
        String grpPrgName = scanner.nextLine();
        return grpPrgName;
    }
    public String inputGrpTutor(){
        System.out.println("Please enter the tutor for the tutorial group(Sir XX Joshua)");
        String grpTutor = scanner.next();
        return grpTutor;
    }
 
    public String inputProgram(){
        System.out.println("Please enter tutorial group programme (Exp: BACS2163): ");
        String tGrpProgramme = scanner.nextLine();
        return tGrpProgramme;
    }
    public String inputTutor(){
        System.out.println("Please enter the tutor for the tutorial group(Exp: SIr Joshua)");
        String tGrpTutor = scanner.nextLine();
        return tGrpTutor;
    }
    
   public Programme inputProgrammeDetails() {
        String prgCode = inputPrgCode();
        String prgName = inputPrgName();
        String prgType = inputPrgType();
        double prgFee = inputPrgFee();
        return new Programme(prgCode,prgName,prgType,prgFee);
  }
    
    public TutorialGroup inputTutorialDetails(){
        int grpId = inputGrpId();
        scanner.nextLine();
        String grpName = inputGrpName();
        String grpProgramme = inputProgram();
        String grpTutor = inputTutor();
        return new TutorialGroup(grpId,grpName,grpProgramme,grpTutor);
    }
    
    
    
}
